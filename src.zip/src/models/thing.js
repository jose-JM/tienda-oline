const {Schema, model} =require('mongoose');

const thingSchema =new Schema({
    title: {
        type : String,
        required:true
    },
    description:{
        type:String,
        required:true
    },
    precio:{
        type:String,
        required:true
    },
    user:{
        type:String,
        required:true
    }
}, {
    timestamps:true
})

module.exports=model('Thing', thingSchema);