const {Router} = require ('express');
const router = Router();

const {
    renderthingForm,
    createNewthing,
    renderthing,
    renderEditForm,
    updatething,
    deletething
}=require('../controllers/thing.controller');

const {isAuthenticated} = require('../helpers/valid');

router.get('/thing/add',isAuthenticated ,renderthingForm);
router.post('/thing/new-thing',isAuthenticated ,createNewthing);
router.get('/thing',isAuthenticated ,renderthing);
router.get('/thing/edit/:id',isAuthenticated ,renderEditForm);
router.put('/thing/edit/:id',isAuthenticated , updatething);
router.delete('/thing/delete/:id',isAuthenticated , deletething);

module.exports=router;
