const thingsCtrl = {};

const Thing = require('../models/thing');




thingsCtrl.renderthingForm = (req, res) => {
    res.render('thing/new-thing');
};


thingsCtrl.createNewthing = async (req, res) => {
    const {
        title,
        description,
        precio
    } = req.body;
    const newthing = new Thing({ title: title, description: description, precio: precio });
    newthing.user = req.user.id;
    await newthing.save();

    req.flash('success_msj', 'thing added');
    res.redirect('/thing');
};


thingsCtrl.renderthing = async (req, res) => {
    const thing = await Thing.find({ user: req.user.id });
    res.render('thing/all-thing', { thing });
};


thingsCtrl.renderEditForm = async (req, res) => {
    const thing = await Thing.findById(req.params.id);
    if (thing.user != req.user.id) {
        req.flash('error_msj', 'no autorizado');
        return res.redirect('/thing');
    }
    res.render('thing/edit-thing', { thing: thing });
};


thingsCtrl.updatething = async (req, res) => {
    const { title, description, precio } = req.body;
    await Thing.findByIdAndUpdate(req.params.id, { title: title, description: description, precio: precio });
    req.flash('success_msj', 'thing updated');
    res.redirect('/thing');
};


thingsCtrl.deletething = async (req, res) => {
    await Thing.findByIdAndDelete(req.params.id);
    req.flash('success_msj', 'delete thing');
    res.redirect('/thing');
};


module.exports = thingsCtrl;