const indexCtrl = {};
const Thing = require('../models/thing');

indexCtrl.renderIndex= async(req, res) => {
    const thing1 = await Thing.find();
    console.log(thing1);
    res.render('index',{thing1});
};

indexCtrl.renderAbout=(req,res)=>{

    res.render('about');
    
};


module.exports=indexCtrl;