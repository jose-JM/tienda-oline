const User = require ('../models/user');

const passport =require('passport');

const usersCtrl ={};

    usersCtrl.renderSignUpForm=async  (req,res)=>{
        res.render('users/signup');
    }

    usersCtrl.signup =async (req,res)=> {
        const errors =[];
        const {name,email,password,confirm_password}=req.body;
    
        if (password != confirm_password) {
            errors.push({
                text:'no coincide'
            });
        }
        if (password.length < 4) {
            errors.push({
                text:'es muy corta'
            });
        }
        if (errors.length>0) {
            res.render('users/signup',{
                errors,
                name,
                email

            });
        }else{
          const emailuser= await User.findOne({email:email});
          if (emailuser) {
              req.flash('error_msj','correo ya registrado');
              res.redirect('/users/signup');
          }else{
              const newUser = new User({name,email,password});
              newUser.password =await newUser.encrypass(password);
              await newUser.save();
              req.flash('success_msj','correo creado');
              res.redirect('/users/signin')
          }
        }


        
    }

    usersCtrl.renderSigninForm=(req,res)=>{
        res.render('users/signin');
    }

    usersCtrl.signin =passport.authenticate('local',{
        failureRedirect:'/users/signin',
        successRedirect:'/thing',
        failureFlash:true
    })

    usersCtrl.logout =(req,res) =>{
        req.logout();

        req.flash('success_msj','sesion cerrrada');
        res.redirect('/users/signin');
    }

module.exports=usersCtrl;